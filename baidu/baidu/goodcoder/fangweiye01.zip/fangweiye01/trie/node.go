package trie

import (
	"sync"

	"icode.baidu.com/baidu/goodcoder/fangweiye/dict"
)

// node 定义前缀树节点
type node struct {
	rw       *sync.RWMutex
	char     rune
	children map[rune]*node
	isEnd    bool
	words    []dict.Word
}

// newNode 创建一个新的前缀树节点
func newNode() *node {
	return &node{
		children: make(map[rune]*node),
		isEnd:    false,
		rw:       &sync.RWMutex{},
	}
}

// search 递归查找当前节点的前缀树后子树满足条件的词组
func (n *node) search(prefix string, word string, result *[]dict.Word) {
	if n.isEnd {
		*result = append(*result, n.words...)
		if prefix == word {
			*result = n.words
			return
		}
	}
	n.rw.RLock()
	for key, value := range n.children {
		value.search(prefix, word+string(key), result)
	}
	n.rw.RUnlock()
}
