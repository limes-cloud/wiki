package trie

import (
	"icode.baidu.com/baidu/goodcoder/fangweiye/dict"
)

// Tree 前缀树接口定义
type Tree interface {
	// Search 通过前缀匹配所有的符合前缀条件的中文词组
	Search(prefix string) ([]dict.Word, bool)
	// Insert 新增中文词组
	Insert(spell string, words []dict.Word)
}

type tree struct {
	root *node
}

// New 新建前缀树
func New() Tree {
	t := &tree{}
	t.root = newNode()
	return t
}

// Insert 向前缀树中插入一个词
func (t *tree) Insert(spell string, words []dict.Word) {
	n := t.root
	for _, char := range spell {
		if char < 'a' || char > 'z' {
			return
		}
		// 如果不存在node节点则新建
		rw := n.rw
		rw.Lock()
		if n.children[char] == nil {
			n.children[char] = newNode()
			n.children[char].char = char
		}
		n = n.children[char]
		rw.Unlock()
	}
	// 对最后一个节点打上标记，并写入对应的中文词组
	n.words = words
	n.isEnd = true
}

// Search 通过前缀查询字典列别
func (t *tree) Search(prefix string) ([]dict.Word, bool) {
	n := t.root
	result := make([]dict.Word, 0)

	// 查找前缀不存在，则直接返回
	if len(prefix) == 0 {
		return result, false
	}

	// 判断是否存在查找前缀
	for _, char := range prefix {
		rw := n.rw

		rw.RLock()
		if n.children[char] == nil {
			rw.RUnlock()
			return result, false
		}
		n = n.children[char]
		rw.RUnlock()
	}

	// 存在则通过前缀获取所有后续的子树上的词组
	n.search(prefix, prefix, &result)
	return result, n.isEnd
}
