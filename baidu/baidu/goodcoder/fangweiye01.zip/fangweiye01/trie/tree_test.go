package trie

import (
	"reflect"
	"sort"
	"testing"

	"icode.baidu.com/baidu/goodcoder/fangweiye/dict"
)

// LevelTraversal 进行层级查询
func LevelTraversal(t *tree) [][]string {
	var result [][]string
	var queue []*node

	root := t.root
	for _, item := range root.children {
		queue = append(queue, item)
	}

	for len(queue) > 0 {
		length := len(queue)
		var temp []string

		for i := 0; i < length; i++ {
			n := queue[i]
			temp = append(temp, string(n.char))
			for _, item := range n.children {
				if item != nil {
					queue = append(queue, item)
				}
			}
		}
		sort.Strings(temp)
		result = append(result, temp)
		queue = queue[length:]
	}
	return result
}

// TestTree_Insert 测试插入前缀树
func TestTree_Insert(t *testing.T) {
	tr := &tree{}
	tr.root = newNode()

	tests := []string{"hello", "world", "baidu", "product", "AA", " ", "---", "123"}
	for _, spell := range tests {
		tr.Insert(spell, nil)
	}

	res := [][]string{
		{"b", "h", "p", "w"},
		{"a", "e", "o", "r"},
		{"i", "l", "o", "r"},
		{"d", "d", "l", "l"},
		{"d", "o", "u", "u"},
		{"c"},
		{"t"},
	}

	if !reflect.DeepEqual(res, LevelTraversal(tr)) {
		t.Errorf("insert trie tree error")
	}
}

// TestTree_Search 测试前缀搜索
func TestTree_Search(t *testing.T) {

	tr := New()
	tr.Insert("de", []dict.Word{
		{
			Spell: "de",
			Value: "的",
			Count: 10,
		},
		{
			Spell: "de",
			Value: "得",
			Count: 10,
		},
		{
			Spell: "de",
			Value: "德",
			Count: 4,
		},
		{
			Spell: "de",
			Value: "地",
			Count: 4,
		},
	})

	tr.Insert("zhan", []dict.Word{
		{
			Spell: "zhan",
			Value: "展",
			Count: 9,
		},
		{
			Spell: "zhan",
			Value: "战",
			Count: 6,
		},
		{
			Spell: "zhan",
			Value: "站",
			Count: 6,
		},
	})

	tr.Insert("zhang", []dict.Word{
		{
			Spell: "zhang",
			Value: "长",
			Count: 10,
		},
		{
			Spell: "zhang",
			Value: "张",
			Count: 9,
		},
	})

	tests := []struct {
		input string
		want  []dict.Word
	}{
		{input: "d", want: []dict.Word{
			{
				Spell: "de",
				Value: "的",
				Count: 10,
			},
			{
				Spell: "de",
				Value: "得",
				Count: 10,
			},
			{
				Spell: "de",
				Value: "德",
				Count: 4,
			},
			{
				Spell: "de",
				Value: "地",
				Count: 4,
			},
		}},
		{input: "", want: []dict.Word{}},
		{input: "AAA", want: []dict.Word{}},
		{input: "-", want: []dict.Word{}},
		{input: "abcdA", want: []dict.Word{}},
		{input: "zha", want: []dict.Word{
			{
				Spell: "zhan",
				Value: "展",
				Count: 9,
			},
			{
				Spell: "zhan",
				Value: "战",
				Count: 6,
			},
			{
				Spell: "zhan",
				Value: "站",
				Count: 6,
			},
			{
				Spell: "zhang",
				Value: "长",
				Count: 10,
			},
			{
				Spell: "zhang",
				Value: "张",
				Count: 9,
			},
		}},
	}

	for _, item := range tests {
		res, _ := tr.Search(item.input)
		if !reflect.DeepEqual(item.want, res) {
			t.Errorf("tree search error:%v", item.input)
		}
	}
}
