package inputmethod

import (
	"reflect"
	"testing"
)

// TestInputMethod_FindWords 测试查找词组
func TestInputMethod_FindWords(t *testing.T) {
	im := NewInputMethod([]string{
		"../testdata/de.dat",
		"../testdata/zhan.dat",
		"../testdata/zhang.dat",
		"http://lime.bcc-szth.baidu.com:8001/files/goodcoder/tian.dat",
		"http://lime.bcc-szth.baidu.com:8001/files/goodcoder/wang.dat",
	})

	tests := []struct {
		input string
		want  []string
	}{
		{
			input: "de",
			want:  []string{"的", "得", "地", "德"},
		},
		{
			input: "zha",
			want:  []string{"长", "展", "张", "战", "站"},
		},
		{
			input: "zhang",
			want:  []string{"长", "张"},
		},
		{
			input: "t",
			want:  []string{"甜", "填", "天", "田"},
		},
	}

	for _, item := range tests {
		if !reflect.DeepEqual(im.FindWords(item.input), item.want) {
			t.Errorf("filedwords error:%v", item.input)
		}
	}
}
