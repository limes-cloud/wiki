package inputmethod

import (
	"bufio"
	"fmt"
	"log"
	"os"
	"sort"
	"strings"

	"icode.baidu.com/baidu/goodcoder/fangweiye/dict"
	"icode.baidu.com/baidu/goodcoder/fangweiye/trie"
)

const maxInputCount = 10

// InputMethod 输入法接口
type InputMethod interface {
	// FindWords 查找符合指定前缀的词组
	FindWords(spell string) (words []string)
	// Run 启动执行输入法
	Run()
}

// inputMethod 输入法对象
type inputMethod struct {
	tree trie.Tree
}

// NewInputMethod 新建输入法对象
func NewInputMethod(paths []string) InputMethod {
	ds := dict.New().ParseFromPath(paths)

	tree := trie.New()
	for spell, words := range ds {
		tree.Insert(spell, words)
	}

	return &inputMethod{
		tree: tree,
	}
}

// FindWords 查找符合指定前缀的词组
func (im *inputMethod) FindWords(spell string) []string {
	if len(spell) == 0 {
		return nil
	}

	var results []string

	words, isEnd := im.tree.Search(spell)
	im.sort(words)

	for _, item := range words {
		results = append(results, item.Value)
	}

	results = im.filterDuplicate(results)
	if !isEnd && len(results) > maxInputCount {
		results = results[:maxInputCount]
	}
	return results
}

// filterDuplicate 对输出结果进行去重
func (im *inputMethod) filterDuplicate(slice []string) []string {
	keys := make(map[string]bool)
	var list []string
	for _, entry := range slice {
		if _, value := keys[entry]; !value {
			keys[entry] = true
			list = append(list, entry)
		}
	}
	return list
}

// sort 对输出的结果进行排序
func (im *inputMethod) sort(arr []dict.Word) {
	sort.SliceStable(arr, func(p, q int) bool {
		if arr[p].Count == arr[q].Count {
			return arr[p].Spell < arr[q].Spell
		}
		return arr[p].Count > arr[q].Count
	})
}

// Run 执行并运行输入法
func (im *inputMethod) Run() {
	stdin := bufio.NewReader(os.Stdin)
	for {
		spell, err := stdin.ReadString('\n')
		if err != nil {
			log.Printf("read word error:%v\n", err.Error())
			break
		}
		spell = strings.TrimRight(spell, "\n")
		words := im.FindWords(spell)
		fmt.Println(strings.Join(words, ", "))
	}
}
