package dict

import (
	"errors"
	"io"
	"math/rand"
	"net/http"
	"net/url"
	"os"
	"time"
	"unsafe"
)

// Resource 资源接口定义
type Resource interface {
	// Load 加载指定path资源
	Load() (string, error)
	// LoadFromLocal 从本地加载资源
	LoadFromLocal() (string, error)
	// LoadFromRemote 从服务端加载资源
	LoadFromRemote() (string, error)
}

// resource 负责加载字典的资源对象
type resource struct {
	// path 资源路径
	path string
}

// NewResource 创建resource对象
func NewResource(path string) Resource {
	return &resource{
		path: path,
	}
}

// Load 加载资源，自动识别是本地还是服务端
func (r *resource) Load() (string, error) {
	if r.isRemotePath() {
		return r.LoadFromRemote()
	}
	return r.LoadFromLocal()
}

// LoadFromLocal 从本地加载资源
func (r *resource) LoadFromLocal() (string, error) {
	// 打开文件
	file, err := os.Open(r.path)
	defer file.Close()
	if err != nil {
		return "", nil
	}

	// 读取文件所有内容
	b, err := io.ReadAll(file)
	if err != nil {
		return "", err
	}
	// 以字符串返回
	return *(*string)(unsafe.Pointer(&b)), nil
}

// LoadFromRemote 从远程加载资源
func (r *resource) LoadFromRemote() (string, error) {
	t := time.NewTicker(1 * time.Second)
	defer t.Stop()

	for {
		select {
		case <-t.C:
			return "", errors.New("load resource timeout:" + r.path)
		default:
			// 创建请求对象
			req, err := http.NewRequest(http.MethodGet, r.path, nil)
			if err != nil {
				return "", err
			}
			// 发起请求
			client := http.Client{Timeout: 50 * time.Millisecond}
			resp, clientErr := client.Do(req)
			if clientErr == nil {
				defer resp.Body.Close()
				b, _ := io.ReadAll(resp.Body)
				if len(b) != 0 {
					return *(*string)(unsafe.Pointer(&b)), nil
				}
			}

			r := rand.New(rand.NewSource(time.Now().UnixNano()))
			time.Sleep(time.Duration(r.Intn(100)+30) * time.Millisecond)
		}
	}

}

// isRemotePath 判断路径是否是远端服务路径
func (r *resource) isRemotePath() bool {
	u, err := url.Parse(r.path)
	return err == nil && u.Scheme != "" && u.Host != ""
}
