package dict

import (
	"log"
	"strconv"
	"strings"
	"sync"
	"unicode"
)

// Dict 定义字典接口
type Dict interface {
	// ParseFromPath 解析资源文件为字典对象
	ParseFromPath(paths []string) map[string][]Word
	Parse(spell string, text string) []Word
}

// dict 定义字典结构体对象
type dict struct {
	wg    sync.WaitGroup
	ds    map[string][]Word
	mutex sync.Mutex
}

// Word 定义词结构对象
type Word struct {
	Spell string //拼音
	Value string //中文词
	Count int    //频率
}

// dictPathSuffix 字典资源后缀
const dictPathSuffix = ".dat"

// New 创建字典对象
func New() Dict {
	return &dict{
		wg:    sync.WaitGroup{},
		mutex: sync.Mutex{},
		ds:    make(map[string][]Word),
	}
}

// ParseFromPath 并发解析资源对象
func (d *dict) ParseFromPath(paths []string) map[string][]Word {
	d.setLoadCount(len(paths))
	for _, path := range paths {
		go d.load(path)
	}
	// 等待加载字典资源
	d.waitLoad()
	return d.ds
}

// load 具体的资源加载细节实现
func (d *dict) load(path string) {
	defer d.wg.Done()

	// 判断资源路径是否合法
	if path[len(path)-len(dictPathSuffix):] != dictPathSuffix {
		return
	}

	// 进行资源加载
	rs := NewResource(path)
	text, err := rs.Load()

	if err != nil {
		log.Println("[dict]", "加载资源失败", err.Error())
		return
	}

	spell := d.getSpell(path)
	words := d.Parse(spell, text)

	d.mutex.Lock()
	d.ds[spell] = words
	d.mutex.Unlock()
}

// getSpell 从路径中获取拼音名称
func (d *dict) getSpell(path string) string {
	path = path[strings.LastIndex(path, "/")+1:]
	return path[:len(path)-len(dictPathSuffix)]
}

// Parse 从文本中提取解析可用的中文词组
func (d *dict) Parse(spell string, text string) []Word {
	var words []Word

	// 按照换行对文本进行分割
	lines := strings.Split(text, "\n")

	// 遍历每行提取出符合条件的汉子行
	for _, lineText := range lines {
		lineText = strings.Trim(lineText, "\t")
		arr := strings.Split(lineText, " ")
		// 判断是否为两个长度
		if len(arr) != 2 {
			continue
		}
		// 判断第一个字符是否为汉字
		r := []rune(arr[0])
		if !unicode.Is(unicode.Han, r[0]) {
			continue
		}
		// 判断第二个字符是否为数字
		count, isNum := strconv.Atoi(arr[1])
		if isNum != nil {
			continue
		}
		// 添加进入字典
		words = append(words, Word{
			Spell: spell,
			Value: arr[0],
			Count: count,
		})
	}
	return words
}

// setLoadCount 函数将给定的字典的加载计数设置为指定的数量。
func (d *dict) setLoadCount(count int) {
	d.wg.Add(count)
}

// waitLoad等待加载函数
func (d *dict) waitLoad() {
	d.wg.Wait()
}
