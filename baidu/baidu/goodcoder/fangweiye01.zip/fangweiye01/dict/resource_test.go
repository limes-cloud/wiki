package dict

import (
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
)

// TestResource_Load 测试加载资源对象，自动识别服务端或者本地
func TestResource_Load(t *testing.T) {
	srv := mockResourceServer()
	defer srv.Close()

	tests := []struct {
		input string
		want  string
	}{
		{
			input: "../testdata/de.dat",
			want: `的 10
得 10
德 4
地 10`,
		},
		{
			input: "../testdata/zhan.dat",
			want: `展 9
战 6
站 6`,
		},
		{
			input: "../testdata/zhang.dat",
			want: `长 10
张 9`,
		},
		{
			input: srv.URL + "/files/goodcoder/tian.dat",
			want: `填 10
天 10
甜 11
田 8`,
		},
		{
			input: srv.URL + "/files/goodcoder/wang.dat",
			want: `王 10
网 9
忘 8
旺 6
汪 10`,
		},
	}

	for _, item := range tests {
		rs := NewResource(item.input)
		loadRes, _ := rs.Load()
		if !reflect.DeepEqual(loadRes, item.want) {
			t.Errorf("load resource error:%v", item.input)
		}
	}
}

// TestResource_LoadFromLocal 测试从本地加载资源对象
func TestResource_LoadFromLocal(t *testing.T) {
	tests := []struct {
		input string
		want  string
	}{
		{
			input: "../testdata/de.dat",
			want: `的 10
得 10
德 4
地 10`,
		},
		{
			input: "../testdata/zhan.dat",
			want: `展 9
战 6
站 6`,
		},
		{
			input: "../testdata/zhang.dat",
			want: `长 10
张 9`,
		},
	}

	for _, item := range tests {
		rs := NewResource(item.input)
		loadRes, _ := rs.Load()
		if !reflect.DeepEqual(loadRes, item.want) {
			t.Errorf("load resource error:%v", item.input)
		}
	}
}

// mockResourceServer 返回一个httptest.Server类型的实例
func mockResourceServer() *httptest.Server {
	// API调用处理函数
	healthHandler := func(w http.ResponseWriter, r *http.Request) {
		switch strings.TrimSpace(r.URL.Path) {
		case "/files/goodcoder/wang.dat":
			w.Header().Set("Content-Type", "text/plain")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`王 10
网 9
忘 8
旺 6
汪 10`))
		case "/files/goodcoder/tian.dat":
			w.Header().Set("Content-Type", "text/plain")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`填 10
天 10
甜 11
田 8`))
		default:
			http.NotFoundHandler().ServeHTTP(w, r)
		}
	}

	return httptest.NewServer(http.HandlerFunc(healthHandler))
}

// TestResource_LoadFromRemote 从远程添加资源
func TestResource_LoadFromRemote(t *testing.T) {
	srv := mockResourceServer()
	defer srv.Close()

	tests := []struct {
		input string
		want  string
	}{
		{
			input: srv.URL + "/files/goodcoder/tian.dat",
			want: `填 10
天 10
甜 11
田 8`,
		},
		{
			input: srv.URL + "/files/goodcoder/wang.dat",
			want: `王 10
网 9
忘 8
旺 6
汪 10`,
		},
	}

	for _, item := range tests {
		rs := NewResource(item.input)
		loadRes, err := rs.Load()
		if err != nil {
			t.Error(err.Error())
		}

		if !reflect.DeepEqual(loadRes, item.want) {
			t.Errorf("load resource error:%v", item.input)
		}
	}
}
