package dict

import (
	"net/http"
	"net/http/httptest"
	"reflect"
	"strings"
	"testing"
)

// TestDict_Parse 测试字段解析
func TestDict_Parse(t *testing.T) {
	dt := New()

	tests := []struct {
		name string
		text string
		want []Word
	}{
		{
			name: "de",
			text: `的 10
					得 10
					德 4
					地 10`,
			want: []Word{
				{
					Spell: "de",
					Value: "的",
					Count: 10,
				},
				{
					Spell: "de",
					Value: "得",
					Count: 10,
				},
				{
					Spell: "de",
					Value: "德",
					Count: 4,
				},
				{
					Spell: "de",
					Value: "地",
					Count: 10,
				},
			},
		},
		{
			name: "zhan",
			text: `展 9
					战 6
					站 6`,
			want: []Word{
				{
					Spell: "zhan",
					Value: "展",
					Count: 9,
				},
				{
					Spell: "zhan",
					Value: "战",
					Count: 6,
				},
				{
					Spell: "zhan",
					Value: "站",
					Count: 6,
				},
			},
		},
	}

	for _, item := range tests {
		if !reflect.DeepEqual(dt.Parse(item.name, item.text), item.want) {
			t.Errorf("parse text error:%v", item.name)
		}
	}
}

// mockDictServer 返回一个 httptest.Server 对象
//
// 参数：无
//
// 返回值：*httptest.Server
func mockDictServer() *httptest.Server {
	// API调用处理函数
	healthHandler := func(w http.ResponseWriter, r *http.Request) {
		switch strings.TrimSpace(r.URL.Path) {
		case "/files/goodcoder/wang.dat":
			w.Header().Set("Content-Type", "text/plain")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`王 10
网 9
忘 8
旺 6
汪 10`))
		case "/files/goodcoder/tian.dat":
			w.Header().Set("Content-Type", "text/plain")
			w.WriteHeader(http.StatusOK)
			_, _ = w.Write([]byte(`填 10
天 10
甜 11
田 8`))
		default:
			http.NotFoundHandler().ServeHTTP(w, r)
		}
	}

	return httptest.NewServer(http.HandlerFunc(healthHandler))
}

// TestDict_ParseFromPath 测试字典解析从path列表
func TestDict_ParseFromPath(t *testing.T) {
	dt := New()
	srv := mockDictServer()
	defer srv.Close()

	tests := []struct {
		input string
		name  string
		want  []Word
	}{
		{
			input: "../testdata/de.dat",
			name:  "de",
			want: []Word{
				{
					Spell: "de",
					Value: "的",
					Count: 10,
				},
				{
					Spell: "de",
					Value: "得",
					Count: 10,
				},
				{
					Spell: "de",
					Value: "德",
					Count: 4,
				},
				{
					Spell: "de",
					Value: "地",
					Count: 10,
				},
			},
		},
		{
			input: "../testdata/zhan.dat",
			name:  "zhan",
			want: []Word{
				{
					Spell: "zhan",
					Value: "展",
					Count: 9,
				},
				{
					Spell: "zhan",
					Value: "战",
					Count: 6,
				},
				{
					Spell: "zhan",
					Value: "站",
					Count: 6,
				},
			},
		},
		{
			input: "../testdata/zhang.dat",
			name:  "zhang",
			want: []Word{
				{
					Spell: "zhang",
					Value: "长",
					Count: 10,
				},
				{
					Spell: "zhang",
					Value: "张",
					Count: 9,
				},
			},
		},
		{
			input: "../testdata/zhang.dat",
			name:  "zhang",
			want: []Word{
				{
					Spell: "zhang",
					Value: "长",
					Count: 10,
				},
				{
					Spell: "zhang",
					Value: "张",
					Count: 9,
				},
			},
		},
		{
			input: srv.URL + "/files/goodcoder/tian.dat",
			name:  "tian",
			want: []Word{
				{
					Spell: "tian",
					Value: "填",
					Count: 10,
				},
				{
					Spell: "tian",
					Value: "天",
					Count: 10,
				},
				{
					Spell: "tian",
					Value: "甜",
					Count: 11,
				},
				{
					Spell: "tian",
					Value: "田",
					Count: 8,
				},
			},
		},
		{
			input: srv.URL + "/files/goodcoder/wang.dat",
			name:  "wang",
			want: []Word{
				{
					Spell: "wang",
					Value: "王",
					Count: 10,
				},
				{
					Spell: "wang",
					Value: "网",
					Count: 9,
				},
				{
					Spell: "wang",
					Value: "忘",
					Count: 8,
				},
				{
					Spell: "wang",
					Value: "旺",
					Count: 6,
				},
				{
					Spell: "wang",
					Value: "汪",
					Count: 10,
				},
			},
		},
	}

	result := map[string][]Word{}
	paths := []string{}
	for _, item := range tests {
		paths = append(paths, item.input)
		result[item.name] = item.want
	}
	if !reflect.DeepEqual(dt.ParseFromPath(paths), result) {
		t.Errorf("parse path dict error")
	}
}
