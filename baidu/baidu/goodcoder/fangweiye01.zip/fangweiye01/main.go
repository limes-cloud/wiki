package main

import (
	"os"

	"icode.baidu.com/baidu/goodcoder/fangweiye/inputmethod"
)

// main 是程序的入口函数
// 在main函数中创建一个inputmethod对象，并调用其Run方法
// 参数os.Args[1:]是命令行参数，第一个参数为数据文件路径
func main() {
	im := inputmethod.NewInputMethod(os.Args[1:])
	im.Run()
}
