# 项目名称
简要说明

## 快速开始
如何构建、安装、运行

## 测试
如何执行自动化测试

## 如何贡献
贡献patch流程、质量要求

## 讨论
百度 Go 交流群：1450752

## 链接
[百度 Go 编码规范](https://ku.baidu-int.com/d/dRSz9SmnNb2tes)
[百度内 Go Module 使用指南](https://ku.baidu-int.com/d/SzGt0sD37hWmmp)

