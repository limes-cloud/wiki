package main

import (
	"github.com/gin-contrib/static"
	"github.com/gin-gonic/gin"
	"os"
	"strings"
)

const (
	port = ":8080"
	dir  = "static"
)

func main() {
	r := gin.Default()
	r.Use(static.Serve("/", static.LocalFile(dir, true)))

	r.NoRoute(func(c *gin.Context) {
		// 获取请求类型
		accept := c.Request.Header.Get("Accept")
		flag := strings.Contains(accept, "text/html")
		// 判断是否为html
		if flag {
			// 判断是否存在首页
			content, err := os.ReadFile(dir + "/index.html")
			if (err) != nil {
				c.Writer.WriteHeader(404)
				_, _ = c.Writer.WriteString("Not Found")
				return
			}
			// 返回首页
			c.Writer.WriteHeader(200)
			c.Writer.Header().Add("Accept", "text/html")
			_, _ = c.Writer.Write((content))
			c.Writer.Flush()
		}
	})

	if err := r.Run(port); err != nil {
		panic("start web ui error:" + err.Error())
	}
}
